/* Macros for the header version.
 */

#ifndef VIPS_VERSION_H
#define VIPS_VERSION_H

#define VIPS_VERSION		"7.38.5"
#define VIPS_VERSION_STRING	"7.38.5-Sun Jun 15 14:09:08 EST 2014"
#define VIPS_MAJOR_VERSION	(7)
#define VIPS_MINOR_VERSION	(38)
#define VIPS_MICRO_VERSION	(5)

/* Not really anything to do with versions, but this is a handy place to put
 * it.
 */
#define VIPS_EXEEXT ""

#endif /*VIPS_VERSION_H*/
